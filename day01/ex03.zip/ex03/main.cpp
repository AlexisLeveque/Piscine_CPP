//
// Created by Alexis LEVEQUE on 5/29/18.
//

#include "Zombie.hpp"
#include "ZombieHorde.hpp"
#include <iostream>


int     main() {
    ZombieHorde horde(12);

    horde.announce();

    return 0;
}