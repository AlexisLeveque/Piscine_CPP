//
// Created by Alexis LEVEQUE on 5/29/18.
//

#import "ZombieHorde.hpp"
#include <iostream>
#include <time.h>

ZombieHorde::ZombieHorde( int nbr ) : _nbr_zombie(nbr) {
    std::string names[20] = {"Esteban", "Ethyl", "Keeley", "Brian", "Tiffiny", "Kelsie", "Jessica", "Emery", "Waylon", "Francesca",
                             "Ute", "Vanita", "Chiquita", "Chance", "Oren", "Ivan", "Aline", "Lacresha", "Rupert", "Everett"};
    srand (time(nullptr));




    for (int i = 0; i < nbr; ++i) {
        _horde[i] = new Zombie(names[rand() % 20], std::string("undead"));
    }
}

ZombieHorde::~ZombieHorde() {
    for (int i = 0; i < _nbr_zombie; ++i) {
        delete _horde[i];
    }
}

void ZombieHorde::announce() {
    for (int i = 0; i < _nbr_zombie; ++i) {
        _horde[i]->announce();
    }
}
